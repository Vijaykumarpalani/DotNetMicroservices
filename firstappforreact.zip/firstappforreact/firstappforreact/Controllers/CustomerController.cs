﻿using SampleCustomerAPI.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace firstappforreact.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class CustomerController : ControllerBase
    {
        private readonly ILogger<CustomerController> _logger;
        public CustomerController(ILogger<CustomerController> logger)
        {
            _logger = logger;
        }

        [HttpGet]
        [Route("GetCustomerDetails")]
        // GET: CustomerController/GetCustomerDetails
        public ActionResult<List<Customer>> Details()
        {
            DateTime actualDate1 = new DateTime(1981, 04, 12, 12, 45, 23);
            DateTime actualDate2 = new DateTime(1982, 04, 12, 16, 34, 12);
            double actualDate3 = actualDate2.ToUniversalTime().Subtract(actualDate1).TotalMinutes;
            double hours = actualDate3 / 60;
            double days = hours / 24;
            double weeks = Convert.ToDouble(Convert.ToInt64(days / 7));
            return Ok(LoadCustomerData(days));
        }

        [HttpPost]
        [Route("AddNewCustomerDetails")]
        // GET: CustomerController/AddNewCustomerDetails
        public ActionResult<List<Customer>> AddNewDetails(Customer newCustomer)
        {
            var customers = LoadCustomerData(0);
            customers.Add(newCustomer);

            return Ok(customers);
        }

        private List<Customer> LoadCustomerData(double weeks)
        {
            return new List<Customer>
            {
                new Customer()
                {
                    Id = 1, Name = "Vijay", Age = 44, HomeAddress ="Gothenburg", City = "Stockholm", Company ="Microsoft", Salary = 120000
                },
                new Customer ()
                {
                    Id = 2, Name = "Kumar", Age = 45, HomeAddress ="Gothenburg", City = "Stockholm", Company ="Microsoft", Salary = 150000
                },
                new Customer ()
                {
                    Id = 3, Name = "Sankar", Age = 40, HomeAddress ="Bangalore", City = "Karnataka", Company ="Samsung", Salary = 160000
                },
                new Customer ()
                {
                    Id = 4, Name = "Suthan", Age = 46, HomeAddress ="Chennai", City = "Tamilnadu", Company ="CTS", Salary = weeks
                },
                new Customer ()
                {
                    Id = 5, Name = "Karthick", Age = 40, HomeAddress ="Chennai", City = "Tamilnadu", Company ="Pharma", Salary = weeks
                }
            };
        }
    }
}
