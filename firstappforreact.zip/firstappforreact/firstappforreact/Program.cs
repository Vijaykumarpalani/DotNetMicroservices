using SampleCustomerAPI.Middleware;
using Microsoft.AspNetCore.Diagnostics.HealthChecks;
using Microsoft.OpenApi.Models;
using Serilog;
using Swashbuckle.AspNetCore.SwaggerUI;
using HealthChecks.UI.Client;
using Serilog.Filters;
using Azure.Identity;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Azure.Core;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using SampleCustomerAPI.Handlers;
using Microsoft.AspNetCore.Authorization;
using SampleCustomerAPI.DAL;
using SampleCustomerAPI.Interfaces.DAL;
using SampleCustomerAPI.Helpers;
using SampleCustomerAPI.Interfaces;
using SampleCustomerAPI.SwaggerFilters.Attributes;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using System.Reflection;
using System.Text.Json.Serialization;
using Swashbuckle.AspNetCore.Filters;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllers();
// Add other services
builder.Services.AddLogging();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(options =>
{
    options.CustomSchemaIds(type => type.FullName);
    //options.IncludeXmlComments($"{AppContext.BaseDirectory}{Path.DirectorySeparatorChar}{environment.ApplicationName}.xml");
    options.SwaggerDoc("v1", new OpenApiInfo { Title = "Customer Interest Rate Calculator", Version = "1.0" });
    options.AddSecurityDefinition("Bearer", //Name the security scheme
        new OpenApiSecurityScheme
        {
            Description = "JWT Authorization header using the Bearer scheme.",
            Type = SecuritySchemeType.Http, //We set the scheme type to http since we're using bearer authentication
            Scheme = "bearer" //The name of the HTTP Authorization scheme to be used in the Authorization header. In this case "bearer".
        });

    options.AddSecurityRequirement(new OpenApiSecurityRequirement{
                    {
                        new OpenApiSecurityScheme{
                            Reference = new OpenApiReference{
                                Id = "Bearer", //The name of the previously defined security scheme.
                                Type = ReferenceType.SecurityScheme
                            }
                        }, new List<string>()
                    }
                });
});


// Configure Serilog
Log.Logger = new LoggerConfiguration()
    .Enrich.FromLogContext()
    .ReadFrom.Configuration(builder.Configuration)
    .Filter.ByExcluding(Matching.WithProperty<string>("RequestPath", p => p == "/"))
    .Filter.ByExcluding(Matching.WithProperty<string>("RequestPath", p => p == "/healthcheck"))
    .Filter.ByExcluding(Matching.WithProperty<string>("RequestPath", p => p.StartsWith("/swagger")))
    .CreateLogger();

var connectionString = Environment.GetEnvironmentVariable("SQL_CONNECTION_STRING");
Log.Information("Connection String: {connectionString}", connectionString);
var clientId = Environment.GetEnvironmentVariable("USER_ASSIGNED_MANAGEMENT_CLIENT_ID");

builder.Services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();

builder.Services.AddDbContextPool<CustomerContext>((serviceProvider, optionsBuilder) =>
{
    var sqlConnection = new SqlConnection(connectionString);

    if (clientId != null)
    {
        var credential = new ManagedIdentityCredential(clientId);
        // Use AccessTokenCallback to fetch a fresh token whenever needed
        sqlConnection.AccessTokenCallback = async (authParams, cancellationToken) =>
        {
            var token = await credential.GetTokenAsync(new TokenRequestContext(["https://database.windows.net/.default"]), cancellationToken);
            return new SqlAuthenticationToken(token.Token, token.ExpiresOn);
        };
    }

    optionsBuilder.UseSqlServer(sqlConnection, x =>
    {
        x.EnableRetryOnFailure();
        x.MigrationsHistoryTable("_EFMigrationHistory", "Customer");
        x.UseQuerySplittingBehavior(QuerySplittingBehavior.SplitQuery);
    });
});

var audience = Environment.GetEnvironmentVariable("JWT_AUDIENCE") ?? builder.Configuration["Jwt:Audience"];

// Add authentication services
builder.Services.AddAuthentication(option =>
{
    option.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    option.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
    option.DefaultScheme = JwtBearerDefaults.AuthenticationScheme;
}).AddJwtBearer(options =>
{
    options.Authority = Environment.GetEnvironmentVariable("JWT_AUTHORITY") ?? builder.Configuration["Jwt:authority"];
    options.Audience = audience;
    options.TokenValidationParameters = new TokenValidationParameters
    {
        ValidAudience = audience,
        ValidIssuer = Environment.GetEnvironmentVariable("JWT_ISSUER") ?? builder.Configuration["Jwt:Issuer"],
        ValidateIssuer = true,
        ValidateAudience = true,
        ValidateLifetime = false,
        ValidateIssuerSigningKey = true
    };
});

builder.Services.AddSingleton<IAuthorizationHandler, DynamicPolicyHandler>();
builder.Services.AddScoped<IRepository, Repository>();
builder.Services.AddScoped<IAuthenticatedUserTokenClaimsHelper, AuthenticatedUserTokenClaimsHelper>();

//builder.Services.AddHybridCache();

builder.Services.AddHealthChecks()
   .AddCheck("API Health Check", () => HealthCheckResult.Healthy("API is running."))
   .AddDbContextCheck<CustomerContext>("Database Health Check");

builder.Services.AddSwaggerExamplesFromAssemblies(Assembly.GetEntryAssembly());

builder.Services.AddAuthorizationBuilder()
    .AddPolicy("Read", policy => policy.Requirements.Add(new DynamicPolicyRequirement() { DynamicPolicyName = "ConfigurationName", PolicyName = "Read" }))
    .AddPolicy("Write", policy => policy.Requirements.Add(new DynamicPolicyRequirement() { DynamicPolicyName = "ConfigurationName", PolicyName = "Write" }))
    .AddPolicy("Read.Customers", policy => policy.RequireRole("Read.Customers"));

builder.Services.AddControllers()
    .AddJsonOptions(opts =>
    {
        opts.JsonSerializerOptions.Converters.Add(new JsonStringEnumConverter());
        opts.JsonSerializerOptions.DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull;
    });

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseCors(x => x.AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod());
app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();
Configure(app, true);

app.Run();

void Configure(IApplicationBuilder app, bool enableSwagger)
{
    app.UseMiddleware<SecurityHeadersMiddleware>();
    app.UseSerilogRequestLogging(); // Log HTTP requests
    app.UseMiddleware<RequestResponseLoggingMiddleware>();
    app.UseMiddleware<ExceptionMiddleware>();
    app.UseMiddleware<JwtMiddleware>();
    app.UseMiddleware<RateLimitMiddleware>();

    app.UseRouting();

    if (enableSwagger)
    {
        app.UseSwagger();
        app.UseSwaggerUI(c =>
        {
            c.SwaggerEndpoint($"/swagger/v1/swagger.json", "Customer Interest Rate Calculator");
            c.DocExpansion(DocExpansion.None);
        });
    }

    app.UseCors(x => x.AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod());
    app.UseHttpsRedirection();

    app.UseHealthChecks($"/healthcheck", new HealthCheckOptions
    {
        Predicate = _ => true,
        ResponseWriter = UIResponseWriter.WriteHealthCheckUIResponse
    });

    app.UseAuthentication();
    app.UseAuthorization();

    app.UseEndpoints(endpoints =>
    {
        endpoints.MapControllers();
    });
}