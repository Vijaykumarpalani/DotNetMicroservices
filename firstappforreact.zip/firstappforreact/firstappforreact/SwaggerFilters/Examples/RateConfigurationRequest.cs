﻿using SampleCustomerAPI.Model;
using Swashbuckle.AspNetCore.Filters;

namespace SampleCustomerAPI.SwaggerFilters.Examples
{
    /// <summary>
    /// Rate Configuration Request Example
    /// </summary>
    public class RateConfigurationRequestExample : IMultipleExamplesProvider<Customer>
    {
        /// <summary>
        /// Get Examples
        /// </summary>
        /// <returns></returns>
        public IEnumerable<SwaggerExample<Customer>> GetExamples()
        {
            yield return SwaggerExample.Create(
                "NO Request",
                "NO Request",
                new Customer()
                {
                    Name = "name"
                });
        }
    }
}
