﻿using Microsoft.AspNetCore.Authorization;

namespace SampleCustomerAPI.SwaggerFilters.Attributes
{
    /// <summary>
    /// Dynamic Policy Requirement
    /// </summary>
    public class DynamicPolicyRequirement : IAuthorizationRequirement
    {
        /// <summary>
        /// The variable value of the policy name
        /// </summary>
        public string DynamicPolicyName { get; set; }
        /// <summary>
        /// The non variable value of the policy name
        /// </summary>
        public string PolicyName { get; set; }

        /// <summary>
        /// Constructor
        /// </summary>
        public DynamicPolicyRequirement()
        {
            DynamicPolicyName = string.Empty;
            PolicyName = string.Empty;
        }
    }
}
