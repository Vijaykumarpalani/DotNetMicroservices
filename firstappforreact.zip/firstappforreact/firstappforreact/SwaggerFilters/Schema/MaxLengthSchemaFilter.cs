﻿using Microsoft.OpenApi.Models;
using Swashbuckle.AspNetCore.SwaggerGen;
using System.ComponentModel.DataAnnotations;

namespace SampleCustomerAPI.SwaggerFilters.Schema
{
    /// <summary>
    ///   <br />
    /// </summary>
    public class MaxLengthSchemaFilter : ISchemaFilter
    {
        /// <summary>
        /// Applies the specified schema.
        /// </summary>
        /// <param name="schema">The schema.</param>
        /// <param name="context">The context.</param>
        public void Apply(OpenApiSchema schema, SchemaFilterContext context)
        {
            if (context.Type.GetCustomAttributes(typeof(MaxLengthAttribute), true)
                .FirstOrDefault() is MaxLengthAttribute maxLengthAttribute)
            {
                schema.Properties ??= new Dictionary<string, OpenApiSchema>();

                foreach (var property in schema.Properties)
                {
                    if (property.Key.Equals(context.DocumentName, StringComparison.OrdinalIgnoreCase))
                    {
                        property.Value.MaxLength = maxLengthAttribute.Length;
                    }
                }
            }
        }
    }
}
