﻿using Microsoft.AspNetCore.Mvc.Controllers;
using Microsoft.OpenApi.Models;
using Swashbuckle.AspNetCore.SwaggerGen;
using System.ComponentModel.DataAnnotations;

namespace SampleCustomerAPI.SwaggerFilters.Operation
{
    /// <summary>
    /// Path Parameter Validation Rules Filter
    /// </summary>
    public class GeneratePathParamsValidationFilter : IOperationFilter
    {
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="operation">Operation</param>
        /// <param name="context">OperationFilterContext</param>
        public void Apply(OpenApiOperation operation, OperationFilterContext context)
        {
            var pars = context.ApiDescription.ParameterDescriptions;

            foreach (var par in pars)
            {
                var swaggerParam = operation.Parameters.SingleOrDefault(p => p.Name == par.Name);

                var attributes = par.ParameterDescriptor != null ? ((ControllerParameterDescriptor)par.ParameterDescriptor).ParameterInfo.CustomAttributes : null;

                if (attributes != null && attributes.Any() && swaggerParam != null)
                {
                    // Required - [Required]
                    var requiredAttr = attributes.FirstOrDefault(p => p.AttributeType == typeof(RequiredAttribute));
                    if (requiredAttr != null)
                    {
                        swaggerParam.Required = true;
                    }

                    // Regex Pattern [RegularExpression]
                    var regexAttr = attributes.FirstOrDefault(p => p.AttributeType == typeof(RegularExpressionAttribute));
                    if (regexAttr != null)
                    {
                        string regex = (string)(regexAttr.ConstructorArguments[0].Value ?? "");
                        if (swaggerParam is OpenApiParameter parameter)
                        {
                            parameter.Schema.Pattern = regex;
                        }
                    }

                    // String Length [StringLength]
                    int? minLenght = null, maxLength = null;
                    var stringLengthAttr = attributes.FirstOrDefault(p => p.AttributeType == typeof(StringLengthAttribute));
                    if (stringLengthAttr != null)
                    {
                        if (stringLengthAttr.NamedArguments.Count == 1)
                        {
                            var minLenghtValue = stringLengthAttr.NamedArguments.Single(p => p.MemberName == "MinimumLength").TypedValue.Value;
                            if (minLenghtValue != null)
                            {
                                minLenght = (int)minLenghtValue;
                            }
                        }
                        var maxLengthValue = stringLengthAttr.ConstructorArguments[0].Value;
                        if (maxLengthValue != null)
                        {
                            maxLength = (int)maxLengthValue;
                        }
                    }

                    var minLengthAttr = attributes.FirstOrDefault(p => p.AttributeType == typeof(MinLengthAttribute));
                    if (minLengthAttr != null)
                    {
                        var minLengthAttrValue = minLengthAttr.ConstructorArguments[0].Value;
                        if (minLengthAttrValue != null)
                        {
                            minLenght = (int)minLengthAttrValue;
                        }
                    }

                    var maxLengthAttr = attributes.FirstOrDefault(p => p.AttributeType == typeof(MaxLengthAttribute));
                    if (maxLengthAttr != null)
                    {
                        var maxLengthAttrValue = maxLengthAttr.ConstructorArguments[0].Value;
                        if (maxLengthAttrValue != null)
                        {
                            minLenght = (int)maxLengthAttrValue;
                        }
                    }

                    if (swaggerParam is OpenApiParameter lengthParameter)
                    {
                        lengthParameter.Schema.MinLength = minLenght;
                        lengthParameter.Schema.MaxLength = maxLength;
                    }

                    // Range [Range]
                    var rangeAttr = attributes.FirstOrDefault(p => p.AttributeType == typeof(RangeAttribute));
                    if (rangeAttr != null)
                    {
                        int rangeMin = (int)(rangeAttr.ConstructorArguments[0].Value ?? 0);
                        int rangeMax = (int)(rangeAttr.ConstructorArguments[1].Value ?? 0);

                        if (swaggerParam is OpenApiParameter rangeParameter)
                        {
                            rangeParameter.Schema.Minimum = rangeMin;
                            rangeParameter.Schema.Maximum = rangeMax;
                        }
                    }
                }
            }
        }
    }
}
