﻿using System.ComponentModel.DataAnnotations.Schema;

namespace SampleCustomerAPI.Model
{
    [Table("Customer", Schema ="Microsoft")]
    [Serializable]
    public class Customer
    {
        /// <summary>
        /// Id
        /// </summary>
        public int Id { get; set; }
        /// <summary>
        /// Name
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// Age
        /// </summary>
        public int Age { get; set; }
        /// <summary>
        /// Home Address
        /// </summary>
        public string HomeAddress { get; set; }
        /// <summary>
        /// City
        /// </summary>
        public string City { get; set; }
        /// <summary>
        /// Salary
        /// </summary>
        public double Salary { get; set; }
        /// <summary>
        /// Company
        /// </summary>
        public string Company { get; set; }

        public Customer()
        {
            Name = string.Empty;
            HomeAddress = string.Empty;
            City = string.Empty;
            Company = string.Empty;
        }
    }
}
