﻿using SampleCustomerAPI.Model;
using Microsoft.EntityFrameworkCore;

namespace SampleCustomerAPI.DAL
{
    public class CustomerContext(DbContextOptions<CustomerContext> options) : DbContext(options)
    {
        public DbSet<Customer> Customers { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
        }
    }
}
