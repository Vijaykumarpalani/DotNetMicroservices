﻿using SampleCustomerAPI.DAL;
using Microsoft.EntityFrameworkCore;
using SampleCustomerAPI.Interfaces.DAL;
using SampleCustomerAPI.Model;

namespace SampleCustomerAPI.DAL
{
    /// <summary>
    /// 
    /// </summary>
    /// <remarks>
    /// 
    /// </remarks>
    /// <param name="context"></param>
    public class Repository(CustomerContext context) : IRepository
    {
        private readonly CustomerContext _context = context;


        /// <summary>
        /// 
        /// </summary>
        /// <param name="customerName"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public async Task<Customer?> GetByCustomerId(string customerName, CancellationToken cancellationToken)
        {
            var result = await _context.Customers
            .FirstOrDefaultAsync(rc => rc.Name == customerName, cancellationToken: cancellationToken);

            return result;

        }
    }
}
