﻿using SampleCustomerAPI.Types.Internal;
using System.Net;

namespace SampleCustomerAPI.Middleware
{
    /// <summary>
    ///   <br />
    /// </summary>
    /// <remarks>Initializes a new instance of the <see cref="RateLimitMiddleware" /> class.</remarks>
    /// <param name="next">The next.</param>
    /// <param name="configuration">The configuration.</param>
    public class RateLimitMiddleware(RequestDelegate next, IConfiguration configuration)
    {
        private readonly RequestDelegate _next = next;
        private readonly Dictionary<string, RateLimitCounter> _rateLimits = [];
        private readonly RateLimitSettings _settings = configuration.GetSection("RateLimitSettings").Get<RateLimitSettings>() ?? new RateLimitSettings();

        /// <summary>Invokes the specified context.</summary>
        /// <param name="context">The context.</param>
        public async Task Invoke(HttpContext context)
        {
            // Get the client's IP address or any other identifier you want to use for rate limiting.
            string clientId = context.Connection.RemoteIpAddress?.ToString() ?? "Unknown";

            if (!_rateLimits.TryGetValue(clientId, out var counter))
            {
                counter = new RateLimitCounter(_settings);
                _rateLimits[clientId] = counter;
            }

            if (!counter.CanMakeRequest())
            {
                // Rate limit exceeded, return an appropriate response (e.g., 429 - Too Many Requests).
                context.Response.StatusCode = (int)HttpStatusCode.TooManyRequests;
                await context.Response.WriteAsync("Rate limit exceeded.");
                return;
            }

            counter.Increment();

            // Call the next middleware in the pipeline.
            await _next(context);
        }
    }
}
