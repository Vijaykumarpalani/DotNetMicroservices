﻿namespace SampleCustomerAPI.Middleware
{
    /// <summary>
    /// 
    /// </summary>
    /// <remarks>
    /// Software header middleware
    /// </remarks>
    /// <param name="next"></param>
    public class SecurityHeadersMiddleware(RequestDelegate next)
    {
        private readonly RequestDelegate _next = next;

        /// <summary>
        /// Invoke the middleware
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public async Task InvokeAsync(HttpContext context)
        {
            // Remove Server header
            context.Response.Headers.Remove("Server");
            context.Response.Headers.Remove("X-Powered-By");
            // Set security headers
            context.Response.Headers.Append("Content-Security-Policy", "default-src 'none'; connect-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:;");
            context.Response.Headers.Append("X-Content-Type-Options", "nosniff");
            context.Response.Headers.Append("X-XSS-Protection", "1; mode=block");
            context.Response.Headers.Append("Strict-Transport-Security", "max-age=31536000; includeSubDomains"); // 31536000 = 1 year
            context.Response.Headers.Append("Referrer-Policy", "strict-origin-when-cross-origin");

            // Add cache control headers
            context.Response.Headers.Append("Cache-Control", "no-store, no-cache, must-revalidate");
            context.Response.Headers.Append("Pragma", "no-cache");
            context.Response.Headers.Append("Expires", "0");

            // Custom path logic
            var path = context.Request.Path.ToString().ToLower();

            // Respond to robots
            if (path.StartsWith("/robot"))
            {
                context.Response.StatusCode = StatusCodes.Status418ImATeapot;
                return;
            }

            if (path == "/")
            {
                context.Response.StatusCode = StatusCodes.Status204NoContent;
                return;
            }

            await _next(context);
        }
    }
}