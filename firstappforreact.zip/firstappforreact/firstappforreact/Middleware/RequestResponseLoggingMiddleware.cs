﻿using System.Diagnostics;
namespace SampleCustomerAPI.Middleware
{
    /// <summary>  
    /// Middleware to log the request and response  
    /// </summary>  
    /// <remarks>
    /// Constructor
    /// </remarks>
    /// <param name="next"></param>
    /// <param name="logger"></param>
    public class RequestResponseLoggingMiddleware(RequestDelegate next, ILogger<RequestResponseLoggingMiddleware> logger)
    {
        private readonly RequestDelegate _next = next;
        private readonly ILogger<RequestResponseLoggingMiddleware> _logger = logger;
        /// <summary>
        /// Invoke the middleware
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public async Task InvokeAsync(HttpContext context)
        {
            var stopwatch = Stopwatch.StartNew();
            using var requestBody = new MemoryStream();
            await context.Request.Body.CopyToAsync(requestBody);
            requestBody.Seek(0, SeekOrigin.Begin);
            var requestBodyText = await new StreamReader(requestBody).ReadToEndAsync();
            requestBody.Seek(0, SeekOrigin.Begin);

            _logger.LogInformation("Handling request: {Url}; Body: {Body}", context.Request.Path, requestBodyText);

            context.Request.Body = requestBody;

            //This is fine to happen before the next middleware, as the response body is not yet written, but will be populated by ref
            var originalResponseBodyStream = context.Response.Body;
            using var responseBody = new MemoryStream();
            context.Response.Body = responseBody;

            await _next(context);

            stopwatch.Stop();
            var elapsedMilliseconds = stopwatch.ElapsedMilliseconds;

            responseBody.Seek(0, SeekOrigin.Begin);
            var responseBodyText = await new StreamReader(responseBody).ReadToEndAsync();
            responseBody.Seek(0, SeekOrigin.Begin);

            _logger.LogInformation(
                "Response: ({StatusCode}) {Response}; Elapsed Time: {ElapsedMilliseconds}ms;",
                context.Response.StatusCode,
                responseBodyText,
                elapsedMilliseconds);

            await responseBody.CopyToAsync(originalResponseBodyStream);
            context.Response.Body = originalResponseBodyStream;

            if (context.Response.StatusCode == 204 && !string.IsNullOrEmpty(responseBodyText))
            {
                context.Response.StatusCode = 200;
            }
            else if (context.Response.StatusCode == 204 && string.IsNullOrEmpty(responseBodyText))
            {
                return;
            }
        }
    }
}
