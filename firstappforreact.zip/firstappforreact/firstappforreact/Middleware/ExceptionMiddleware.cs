﻿using SampleCustomerAPI.Exceptions;
using SampleCustomerAPI.Types.Enums;
using System.ComponentModel.DataAnnotations;
using Microsoft.IdentityModel.Tokens;

namespace SampleCustomerAPI.Middleware
{
    /// <summary>
    ///   <br />
    /// </summary>
    /// <remarks>Initializes a new instance of the <see cref="ExceptionMiddleware" /> class.</remarks>
    /// <param name="next">The next.</param>
    /// <param name="logger"></param>
    public class ExceptionMiddleware(RequestDelegate next, ILogger<ExceptionMiddleware> logger)
    {
        private readonly RequestDelegate _next = next;
        private readonly ILogger<ExceptionMiddleware> _logger = logger;

        /// <summary>Invokes the asynchronous.</summary>
        /// <param name="httpContext">The HTTP context.</param>
        public async Task InvokeAsync(HttpContext httpContext)
        {
            try
            {
                await _next(httpContext);
            }
            catch (Exception ex)
            {
                await HandleExceptionAsync(httpContext, ex);
            }
        }

        private Task HandleExceptionAsync(HttpContext httpContext, Exception ex)
        {
            _logger.LogError("Error: {message} {stackTrace}", ex.Message, ex.StackTrace);
            if (ex.InnerException != null && !ex.InnerException.Message.Equals(ex.Message))
            {
                _logger.LogError("Inner Exception: {message} {stackTrace}", ex.InnerException.Message, ex.InnerException.StackTrace);
            }
            httpContext.Response.ContentType = "application/json";

            httpContext.Response.StatusCode = ex switch
            {
                NotFoundException _ => StatusCodes.Status404NotFound,
                ValidationException _ => StatusCodes.Status400BadRequest,
                ForbiddenException _ => StatusCodes.Status403Forbidden,
                UnauthorizedException _ => StatusCodes.Status401Unauthorized,
                SecurityTokenExpiredException _ => StatusCodes.Status401Unauthorized,
                SecurityTokenException _ => StatusCodes.Status401Unauthorized,
                IntegrationException _ => (ex as IntegrationException)!.Type switch
                {
                    IntegrationExceptionType.Timeout => StatusCodes.Status408RequestTimeout,
                    IntegrationExceptionType.BadRequest => StatusCodes.Status400BadRequest,
                    IntegrationExceptionType.ServiceUnavailable => StatusCodes.Status503ServiceUnavailable,
                    IntegrationExceptionType.BadGateway => StatusCodes.Status502BadGateway,
                    IntegrationExceptionType.GatewayTimeout => StatusCodes.Status504GatewayTimeout,
                    IntegrationExceptionType.InternalServerError => StatusCodes.Status500InternalServerError,
                    _ => StatusCodes.Status500InternalServerError,
                },
                _ => StatusCodes.Status500InternalServerError,
            };
            return httpContext.Response.WriteAsync(ex.Message);
        }
    }
}