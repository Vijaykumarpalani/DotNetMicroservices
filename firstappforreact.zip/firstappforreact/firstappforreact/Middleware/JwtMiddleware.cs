﻿using Microsoft.IdentityModel.Protocols;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using SampleCustomerAPI.Exceptions;

namespace SampleCustomerAPI.Middleware
{
    /// <summary>
    ///  JwtMiddleware
    /// </summary>
    /// <remarks>
    /// JwtMiddleware
    /// </remarks>
    /// <param name="next"></param>
    /// <param name="configuration"></param>
    public class JwtMiddleware(RequestDelegate next, IConfiguration configuration)
    {
        private readonly RequestDelegate _next = next;
        private readonly IConfiguration _configuration = configuration;

        /// <summary>
        /// Invoke the middleware
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public async Task Invoke(HttpContext context)
        {

            // Skip JWT processing for Swagger requests
            if (context.Request.Path.StartsWithSegments("/swagger"))
            {
                await _next(context);
                return;
            }

            // Try to get the token from the Authorization header
            var token = context.Request.Headers.Authorization.FirstOrDefault()?.Split(" ").Last();

            if (!string.IsNullOrEmpty(token))
            {
                // Attempt to attach user context if token is present
                await AttachUserToContext(context, token);
            }
        }

        /// <summary>
        /// Attach user context to the HttpContext
        /// </summary>
        /// <param name="context"></param>
        /// <param name="token"></param>
        /// <returns></returns>
        /// <exception cref="ForbiddenException"></exception>
        private async Task AttachUserToContext(HttpContext context, string token)
        {
            try
            {
                var tokenHandler = new JwtSecurityTokenHandler();
                var issuer = Environment.GetEnvironmentVariable("JWT_ISSUER") ?? _configuration["Jwt:Issuer"];
                var metadataAddress = $"{issuer}.well-known/openid-configuration";
                var configManager = new ConfigurationManager<OpenIdConnectConfiguration>(metadataAddress, new OpenIdConnectConfigurationRetriever());
                var openidconfig = await configManager.GetConfigurationAsync();

                var audience = Environment.GetEnvironmentVariable("JWT_AUDIENCE") ?? _configuration["Jwt:Audience"];

                var validationParameters = new TokenValidationParameters
                {
                    ValidateIssuerSigningKey = true,
                    IssuerSigningKeys = openidconfig.SigningKeys,
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    ValidIssuer = issuer,
                    ValidAudience = audience,
                    ValidAlgorithms = ["RS256"],
                    ClockSkew = TimeSpan.Zero
                };

                context.User = tokenHandler.ValidateToken(token, validationParameters, out SecurityToken validatedToken);

                await _next(context);
            }
            catch(Exception)
            {
                throw;
            }
        }
    }
}
