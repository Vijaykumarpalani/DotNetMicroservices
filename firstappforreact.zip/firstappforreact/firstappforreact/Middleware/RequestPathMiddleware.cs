﻿using Serilog.Context;

namespace SampleCustomerAPI.Middleware
{
    /// <summary>
    /// Middleware to enrich the log context with the request path
    /// </summary>
    /// <remarks>
    /// Constructor
    /// </remarks>
    /// <param name="next"></param>
    public class RequestPathEnricherMiddleware(RequestDelegate next)
    {
        private readonly RequestDelegate _next = next;

        /// <summary>
        /// Invoke the middleware
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public async Task InvokeAsync(HttpContext context)
        {
            using (LogContext.PushProperty("RequestPath", context.Request.Path))
            {
                await _next(context);
            }
        }
    }
}
