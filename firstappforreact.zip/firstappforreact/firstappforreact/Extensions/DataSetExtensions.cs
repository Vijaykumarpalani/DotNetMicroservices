﻿using System.Data.SqlTypes;
using System.Data;
using System.Reflection;
using SampleCustomerAPI.Extensions.DataSet;

namespace SampleCustomerAPI.Extensions
{
    /// <summary>
    /// Extension methods for DataSet.
    /// </summary>
    public static class DataSetExtensions
    {
        /// <summary>
        /// Converts a collection of objects to a DataTable.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="source"></param>
        /// <param name="dataTableName"></param>
        /// <returns></returns>
        public static DataTable ToDataTable<T>(this IEnumerable<T> source, string dataTableName)
        {
            var businessObjects = source as T[] ?? (source ?? []).ToArray();
            var objType = (typeof(T) == typeof(object) ? businessObjects.FirstOrDefault()?.GetType() : null) ?? typeof(T);

            var dt = new DataTable(dataTableName);
            var properties = objType.GetProperties(BindingFlags.Public | BindingFlags.Instance |
                                                   BindingFlags.GetProperty);
            var sortedProperties = SortProperties(objType, properties);
            foreach (var property in sortedProperties)
            {
                var propertyType = property.PropertyType;
                if (propertyType.IsGenericType && propertyType.GetGenericTypeDefinition() == typeof(Nullable<>))
                {
                    // ReSharper disable once AssignNullToNotNullAttribute -- false positive
                    var dc = new DataColumn(property.Name, Nullable.GetUnderlyingType(propertyType) ?? propertyType) { AllowDBNull = true };
                    dt.Columns.Add(dc);
                }
                else if (propertyType.IsEnum)
                {
                    dt.Columns.Add(property.Name, typeof(int));
                }
                else
                {
                    dt.Columns.Add(property.Name, propertyType);
                }
            }

            foreach (var businessObject in businessObjects)
            {
                var dr = dt.NewRow();
                dt.Rows.Add(dr);

                foreach (var property in properties)
                {
                    var value = property.GetValue(businessObject, null);
                    if (property.PropertyType.IsGenericType &&
                        property.PropertyType.GetGenericTypeDefinition() == typeof(Nullable<>) && value == null)
                    {
                        dr[property.Name] = DBNull.Value;
                    }
                    else
                    {
                        var dataType = dt.Columns[property.Name]?.DataType;
                        if (dataType != null)
                        {
                            dr[property.Name] = GetGuardedValue(dataType, value);
                        }
                    }
                }
            }

            StripNullFromDataTable(dt);
            return dt;
        }

        private static object GetGuardedValue(Type dataType, object? value)
        {
            if (value == null)
            {
                return DBNull.Value;
            }

            object correctedValue = dataType.FullName switch
            {
                "System.DateTime" when value is DateTime dVal && dVal < SqlDateTime.MinValue.Value => SqlDateTime.MinValue.Value,
                "System.DateTime" when value is DateTime dVal && dVal > SqlDateTime.MaxValue.Value => SqlDateTime.MaxValue.Value,
                "System.Double" when value is double dVal && dVal.IsZeroWithEpsilonPrecision() => 0d,
                "System.Double" when value is double dVal && double.IsInfinity(dVal) => 0d,
                "System.Double" when value is double dVal && double.IsNaN(dVal) => 0d,
                "System.Double" when value is double dVal && dVal < SqlDouble.MinValue.Value => SqlDouble.MinValue.Value,
                "System.Double" when value is double dVal && dVal > SqlDouble.MaxValue.Value => SqlDouble.MaxValue.Value,
                _ => value,
            };
            return correctedValue;
        }

        private static PropertyInfo[] SortProperties(MemberInfo objectType, PropertyInfo[] properties)
        {
            var sortProperties = objectType.GetCustomAttribute<DataObjectConversionAttribute>()?.SortProperties ??
                                 SortPropertiesMethod.NoSorting;
            return sortProperties switch
            {
                SortPropertiesMethod.NoSorting => properties,
                SortPropertiesMethod.SortAlphabetic => [.. properties.OrderBy(pi => pi.Name)],
                _ => throw new NotSupportedException($"Sort method {sortProperties} not supported"),
            };
        }

        /// <summary>
        /// Check if a double is zero with epsilon precision.
        /// </summary>
        /// <param name="number"></param>
        /// <returns></returns>
        public static bool IsZeroWithEpsilonPrecision(this double number)
        {
            return double.IsNaN(number) || Math.Abs(number) <= double.Epsilon;
        }

        private static void StripNullFromDataTable(DataTable table)
        {
            List<DataColumn> toBeRemoved = [];
            foreach (DataColumn column in table.Columns)
            {
                if (column.ColumnName != "InterestRate")
                {
                    if (table.AsEnumerable().All(r => r.Field<string>(column.ColumnName) == null))
                        toBeRemoved.Add(column);
                }
            }

            foreach (DataColumn column in toBeRemoved)
            {
                table.Columns.Remove(column);
            }

        }

    }
}
