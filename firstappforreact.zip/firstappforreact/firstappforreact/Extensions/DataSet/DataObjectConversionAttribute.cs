﻿namespace SampleCustomerAPI.Extensions.DataSet
{
    /// <summary>
    /// Attribute to specify how to sort the properties of a class or struct when converting to a DataTable.
    /// </summary>
    /// <param name="sortProperties"></param>
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Struct, Inherited = false)]
    public class DataObjectConversionAttribute(SortPropertiesMethod sortProperties) : System.Attribute
    {
        /// <summary>
        /// Sort properties method.
        /// </summary>
        public SortPropertiesMethod SortProperties { get; set; } = sortProperties;
    }
}
