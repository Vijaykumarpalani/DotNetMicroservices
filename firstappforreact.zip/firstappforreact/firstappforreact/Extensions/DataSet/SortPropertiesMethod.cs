﻿namespace SampleCustomerAPI.Extensions.DataSet
{
    /// <summary>
    /// Sort Properties Method
    /// </summary>
    public enum SortPropertiesMethod
    {
        /// <summary>
        /// No Sorting
        /// </summary>
        NoSorting,
        /// <summary>
        /// Sort Alphabetic
        /// </summary>
        SortAlphabetic,
    }
}
