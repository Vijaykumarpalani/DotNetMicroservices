﻿namespace SampleCustomerAPI.Extensions
{
    /// <summary>
    /// Value Pair Extensions
    /// </summary>
    public static class ValuePairExtensions
    {
        /// <summary>
        /// Is Equal
        /// </summary>
        /// <param name="self"></param>
        /// <param name="other"></param>
        /// <returns></returns>
        public static bool IsEqual(this KeyValuePair<string, string> self, KeyValuePair<string, string> other)
        {
            var isEqual = string.Equals(self.Key, other.Key, StringComparison.OrdinalIgnoreCase) && string.Equals(self.Value, other.Value, StringComparison.OrdinalIgnoreCase);
            return isEqual;
        }

        /// <summary>
        /// Is Equal
        /// </summary>
        /// <param name="self"></param>
        /// <param name="other"></param>
        /// <returns></returns>
        public static (bool IsEqual, string Message) IsEqual(this IEnumerable<KeyValuePair<string, string>> self, IEnumerable<KeyValuePair<string, string>> other)
        {
            var message = string.Empty;
            var isEqual = self.Count() == other.Count();
            if (!isEqual)
            {
                message = "IncorrectNumberOfParameters";
                (bool IsEqual, string Message) result = (false, message);
                return result;
            }

            foreach (var item in self)
            {
                isEqual &= other.Any(s => s.IsEqual(item));
            }

            if (!isEqual)
            {
                message = "NoMatch";
                (bool IsEqual, string Message) result = (false, message);
                return result;
            }
            else
            {
                (bool IsEqual, string Message) result = (true, message);
                return result;
            }
        }
    }
}
