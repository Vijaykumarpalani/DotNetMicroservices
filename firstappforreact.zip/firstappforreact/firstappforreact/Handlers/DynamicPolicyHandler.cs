﻿using SampleCustomerAPI.SwaggerFilters.Attributes;
using Microsoft.AspNetCore.Authorization;

namespace SampleCustomerAPI.Handlers
{
    /// <summary>
    /// Dynamic Read Handler
    /// </summary>
    public class DynamicPolicyHandler : AuthorizationHandler<DynamicPolicyRequirement>
    {
        /// <summary>
        /// Handle Requirements Asyncrounously
        /// </summary>
        /// <param name="context"></param>
        /// <param name="requirement"></param>
        /// <returns></returns>
        protected override Task HandleRequirementAsync(AuthorizationHandlerContext context, DynamicPolicyRequirement requirement)
        {
            if (context.Resource is HttpContext httpContext)
            {
                var request = httpContext.Request;
                var routeValues = request.RouteValues;
                var dynamicNameValue = routeValues[requirement.DynamicPolicyName];

                if (dynamicNameValue != null)
                {
                    var claimPattern = $"{requirement.PolicyName}.{dynamicNameValue}";

                    bool hasRequiredClaim = context.User.HasClaim(claim => claim.Value.Equals(claimPattern, StringComparison.CurrentCultureIgnoreCase)) ||
                                            context.User.IsInRole(claimPattern);

                    if (hasRequiredClaim)
                    {
                        context.Succeed(requirement);
                    }
                    else
                    {
                        context.Fail();
                    }
                }
                else
                {
                    context.Fail();
                }
            }
            else
            {
                context.Fail();
            }

            return Task.CompletedTask;
        }
    }
}