﻿using System.Text.Json;
using System.Text;
using System.Text.Json.Serialization;
using System.Reflection;

namespace SampleCustomerAPI.Helpers
{
    /// <summary>
    ///   <br />
    /// </summary>
    public static class JsonHelper
    {
        /// <summary>Serializes the specified input.</summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="input">The input.</param>
        /// <returns>
        ///   <br />
        /// </returns>
        public static string Serialize<T>(T input)
        {
            if (input == null)
                return string.Empty;

            return JsonSerializer.Serialize<T>(input);
        }

        /// <summary>Deserializes from string.</summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="message">The message.</param>
        /// <returns>
        ///   <br />
        /// </returns>
        public static T? DeserializeFromString<T>(string message)
        {
            return JsonSerializer.Deserialize<T>(message);
        }

        /// <summary>Deserializes from file.</summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="filename">The filename.</param>
        /// <param name="encoding">The encoding.</param>
        /// <returns>
        ///   <br />
        /// </returns>
        public static T? DeserializeFromFile<T>(string filename, Encoding encoding)
        {
            var json = File.ReadAllText(filename, encoding);

            return JsonSerializer.Deserialize<T>(json);
        }
    }
}
