﻿using SampleCustomerAPI.Interfaces;
using SampleCustomerAPI.Types.UserAudit;
using System.Security.Claims;

namespace SampleCustomerAPI.Helpers
{

    /// <summary>
    /// TokenClaimsHelper
    /// </summary>
    public class AuthenticatedUserTokenClaimsHelper : IAuthenticatedUserTokenClaimsHelper
    {

        /// <summary>
        /// Get the authenticated user details from the claims principal
        /// </summary>
        /// <param name="claimsPrincipal"></param>
        /// <returns></returns>
        public AuthenticatedUserDetails GetAuthenticatedUserDetails(ClaimsPrincipal claimsPrincipal)
        {
            var uniqueName = claimsPrincipal.FindFirst(ClaimTypes.Upn)?.Value
                             ?? claimsPrincipal.FindFirst(ClaimTypes.Name)?.Value;

            var appId = claimsPrincipal.FindFirst("appid")?.Value ?? throw new UnauthorizedAccessException($"Invalid accesstoken.");
            var oId = claimsPrincipal.FindFirst("http://schemas.microsoft.com/identity/claims/objectidentifier")?.Value;

            var userType = IsLoggedInUser(oId, uniqueName) ? UserType.LoggedInUser : UserType.Application;
            var userId = GetUserId(userType, appId, oId);

            return new AuthenticatedUserDetails
            {
                UniqueName = uniqueName,
                UserId = userId,
                UserType = userType
            };
        }

        private static bool IsLoggedInUser(string oid, string uniqueName)
        {
            return !string.IsNullOrEmpty(oid) && !string.IsNullOrEmpty(uniqueName);
        }

        private static string GetUserId(UserType userType, string appId, string oId)
        {
            var userId = userType == UserType.LoggedInUser ? oId : appId;
            return userId;
        }
    }
}
