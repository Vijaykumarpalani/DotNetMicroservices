﻿using System.Text.Json;
using System.Text.Json.Serialization;
using System.Reflection;

namespace SampleCustomerAPI.Helpers
{
    /// <summary>
    /// Dynamic Converter for JSON serialization and deserialization
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class DynamicConverter<T> : JsonConverter<T> where T : class, new()
    {
        /// <summary>
        /// Reads and converts the JSON to an object of type T.
        /// </summary>
        /// <param name="reader"></param>
        /// <param name="typeToConvert"></param>
        /// <param name="options"></param>
        /// <returns></returns>
        public override T Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
        {
            var obj = new T();
            var properties = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);

            while (reader.Read())
            {
                if (reader.TokenType == JsonTokenType.EndObject)
                {
                    return obj;
                }

                if (reader.TokenType == JsonTokenType.PropertyName)
                {
                    string? propertyName = reader.GetString();
                    reader.Read();

                    var property = properties.FirstOrDefault(p => p.Name.Equals(propertyName, StringComparison.OrdinalIgnoreCase));
                    if (property != null)
                    {
                        var value = JsonSerializer.Deserialize(ref reader, property.PropertyType, options);
                        property.SetValue(obj, value);
                    }
                }
            }

            return obj;
        }

        /// <summary>
        /// Writes the object of type T to JSON.
        /// </summary>
        /// <param name="writer"></param>
        /// <param name="value"></param>
        /// <param name="options"></param>
        public override void Write(Utf8JsonWriter writer, T value, JsonSerializerOptions options)
        {
            writer.WriteStartObject();

            var properties = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
            foreach (var property in properties)
            {
                var propertyValue = property.GetValue(value);
                if (propertyValue != null && !(propertyValue is string str && string.IsNullOrEmpty(str)))
                {
                    // Apply camel case naming policy
                    var propertyName = options.PropertyNamingPolicy?.ConvertName(property.Name) ?? property.Name;
                    writer.WritePropertyName(propertyName);
                    JsonSerializer.Serialize(writer, propertyValue, options);
                }
            }

            writer.WriteEndObject();
        }

    }
}