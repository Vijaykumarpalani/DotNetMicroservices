﻿using SampleCustomerAPI.Types.Configuration;

namespace SampleCustomerAPI.Types.RequestModels
{
    /// <summary>
    /// Rate Configuration Request Model
    /// </summary>
    public class RateConfigurationRequestModel
    {
        /// <summary>
        /// Gets or sets the Id
        /// </summary>
        public int Id { get; set; }
        /// <summary>
        /// Gets or sets the Calculation Type
        /// </summary>
        public CalculationType CalculationType { get; set; }
    }
}
