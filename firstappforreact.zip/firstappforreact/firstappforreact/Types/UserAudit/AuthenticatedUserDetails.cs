﻿namespace SampleCustomerAPI.Types.UserAudit
{
    /// <summary>
    /// UserDetails
    /// </summary>
    public class AuthenticatedUserDetails
    {
        /// <summary>
        /// Gets or sets the UniqueName
        /// </summary>
        public string? UniqueName { get; set; }
        /// <summary>
        /// Gets or sets the Userd
        /// </summary>
        public string UserId { get; set; }

        /// <summary>
        /// Gets or sets the UserType
        /// </summary>
        public UserType UserType { get; set; }

        /// <summary>
        /// Gets the authenticated username
        /// </summary>
        public string AuthenticatedUsername => UserType == UserType.LoggedInUser ? UniqueName ?? "User" : "Application";

        /// <summary>
        /// Constructor
        /// </summary>
        public AuthenticatedUserDetails()
        {
            this.UniqueName = string.Empty;
            this.UserId = string.Empty;
        }
    }
}
