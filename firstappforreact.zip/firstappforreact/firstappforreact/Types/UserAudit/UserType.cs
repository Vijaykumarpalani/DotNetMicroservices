﻿namespace SampleCustomerAPI.Types.UserAudit
{
    /// <summary>
    /// User Type
    /// </summary>
    public enum UserType
    {
        /// <summary>
        /// Application
        /// </summary>
        Application = 1,
        /// <summary>
        /// Logged in user
        /// </summary>
        LoggedInUser = 2
    }
}
