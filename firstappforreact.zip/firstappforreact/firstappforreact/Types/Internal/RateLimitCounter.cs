﻿namespace SampleCustomerAPI.Types.Internal
{
    /// <summary>
    ///  RateLimitCounter
    /// </summary>
    /// <remarks>Initializes a new instance of the <see cref="RateLimitCounter" /> class.</remarks>
    /// <param name="settings">The settings.</param>
    public class RateLimitCounter(RateLimitSettings settings)
    {
        private readonly RateLimitSettings _settings = settings;
        private DateTime _windowStart = DateTime.UtcNow;
        private int _count = 0;

        /// <summary>Determines whether this instance [can make request].</summary>
        /// <returns>
        ///   <c>true</c> if this instance [can make request]; otherwise, <c>false</c>.</returns>
        public bool CanMakeRequest()
        {
            var now = DateTime.UtcNow;
            var elapsedSeconds = (now - _windowStart).TotalSeconds;

            if (elapsedSeconds >= _settings.TimeInSeconds)
            {
                // Reset the counter and start a new time window.
                _windowStart = now;
                _count = 0;
            }

            return _count < _settings.RequestCount;
        }

        /// <summary>Increments this instance.</summary>
        public void Increment()
        {
            _count++;
        }
    }
}
