﻿namespace SampleCustomerAPI.Types.Internal
{
    /// <summary>
    /// RateLimitSettings
    /// </summary>
    public class RateLimitSettings
    {
        /// <summary>Gets or sets the request count.</summary>
        /// <value>The request count.</value>
        public int RequestCount { get; set; } = 10000;
        /// <summary>Gets or sets the time in seconds.</summary>
        /// <value>The time in seconds.</value>
        public int TimeInSeconds { get; set; } = 3600;
    }
}
