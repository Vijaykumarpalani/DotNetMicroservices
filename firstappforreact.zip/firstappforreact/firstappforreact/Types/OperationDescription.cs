﻿namespace SampleCustomerAPI.Types
{
    /// <summary>
    /// Operation Description
    /// </summary>
    public enum OperationDescription
    {
        /// <summary>
        /// Read Interest Rates
        /// </summary>
        ReadInterestRates = 0,
        /// <summary>
        /// Allowed Parameters
        /// </summary>
        AllowedParameters = 1,
        /// <summary>
        /// Read
        /// </summary>
        Read = 2,
        /// <summary>
        /// Write
        /// </summary>
        Write = 3        
    }
}
