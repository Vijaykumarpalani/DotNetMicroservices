﻿namespace SampleCustomerAPI.Types
{
    /// <summary>
    /// Rate Configuration Type
    /// </summary>
    public enum RateConfigurationType
    {
        /// <summary>
        /// Country
        /// </summary>
        Country = 0,
        /// <summary>
        /// Business Area
        /// </summary>
        BusinessArea,
        /// <summary>
        /// Customer Size
        /// </summary>
        CustomerSize,
        /// <summary>
        /// Grading
        /// </summary>
        Grading,
        /// <summary>
        /// Make
        /// </summary>
        Make,
        /// <summary>
        /// Term
        /// </summary>
        Term,
        /// <summary>
        /// Custom
        /// </summary>
        Custom
    }
}
