﻿namespace SampleCustomerAPI.Types.Enums
{
    /// <summary>
    /// IntegrationExceptionType
    /// </summary>
    public enum IntegrationExceptionType
    {
        /// <summary>Timeout</summary>
        Timeout,
        /// <summary>Bad request</summary>
        BadRequest,
        /// <summary>Bad response</summary>
        BadResponse,
        /// <summary>Bad gateway</summary>
        BadGateway,
        /// <summary>Service unavailable</summary>
        ServiceUnavailable,
        /// <summary>Internal server error</summary>
        InternalServerError,
        ///Gateway timeout
        GatewayTimeout
    }
}