﻿namespace SampleCustomerAPI.Types.Configuration
{
    /// <summary>
    /// Enumeration of allowed parameters for customer interest rate calculation.
    /// </summary>
    [Flags]
    public enum AllowedParameters
    {
        /// <summary>
        /// No parameters allowed.
        /// </summary>
        Empty = 0,

        /// <summary>
        /// Parameter for asset type.
        /// </summary>
        AssetType = 1,

        /// <summary>
        /// Parameter for business area.
        /// </summary>
        BusinessArea = 2,

        /// <summary>
        /// Parameter for chassis type.
        /// </summary>
        ChassisType = 4,

        /// <summary>
        /// Parameter for country.
        /// </summary>
        Country = 8,

        /// <summary>
        /// Parameter for credit rating.
        /// </summary>
        CreditRating = 16,

        /// <summary>
        /// Parameter for customer size.
        /// </summary>
        CustomerSize = 32,

        /// <summary>
        /// Parameter for engine type.
        /// </summary>
        EngineType = 64,

        /// <summary>
        /// Parameter for end of term option.
        /// </summary>
        EOTOption = 128,

        /// <summary>
        /// Parameter for make.
        /// </summary>
        Make = 256,

        /// <summary>
        /// Parameter for market.
        /// </summary>
        Market = 512,

        /// <summary>
        /// Parameter for model.
        /// </summary>
        Model = 1024,

        /// <summary>
        /// Parameter for object type.
        /// </summary>
        ObjectType = 2048,

        /// <summary>
        /// Parameter for segment.
        /// </summary>
        Segment = 4096,

        /// <summary>
        /// Parameter for payments.
        /// </summary>
        Payments = 8192,

        /// <summary>
        /// Parameter for residual value percentage.
        /// </summary>
        RVPercentage = 16384,

        /// <summary>
        /// Parameter for term.
        /// </summary>
        Term = 32768,

        /// <summary>
        /// Parameter for grading.
        /// </summary>
        Grading = 65536,
    }
}
