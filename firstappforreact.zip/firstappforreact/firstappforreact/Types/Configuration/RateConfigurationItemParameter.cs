﻿namespace SampleCustomerAPI.Types.Configuration
{
    /// <summary>
    /// Enumeration for rate configuration item parameters.
    /// </summary>
    public enum RateConfigurationItemParameter
    {
        /// <summary>
        /// No parameters.
        /// </summary>
        Empty = 0,

        /// <summary>
        /// Parameter for country.
        /// </summary>
        Country = 1,

        /// <summary>
        /// Parameter for term.
        /// </summary>
        Term = 2
    }
}
