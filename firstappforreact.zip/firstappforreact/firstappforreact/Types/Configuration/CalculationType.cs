﻿namespace SampleCustomerAPI.Types.Configuration
{
    /// <summary>
    /// Calculation Type
    /// </summary>
    public enum CalculationType
    {
        /// <summary>
        /// None
        /// </summary>
        None = 0,
        /// <summary>
        /// Interest Rate
        /// </summary>
        InterestRate = 1,
        /// <summary>
        /// Cost of Funds
        /// </summary>
        COF = 2,
        /// <summary>
        /// Proforma
        /// </summary>
        Proforma = 3
    }
}
