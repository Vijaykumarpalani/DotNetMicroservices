﻿namespace SampleCustomerAPI.Types
{
    /// <summary>
    /// Configuration Base
    /// </summary>
    public enum ConfigurationBase
    {
        /// <summary>
        /// Interest Rate
        /// </summary>
        InterestRate = 0,
        /// <summary>
        /// Cost of Funds Surcharge
        /// </summary>
        CofSurcharge
    }
}
