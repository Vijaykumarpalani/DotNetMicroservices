﻿using SampleCustomerAPI.Types.Enums;

namespace SampleCustomerAPI.Exceptions
{
    /// <summary>
    /// 
    /// </summary>
    public class IntegrationException : Exception
    {
        /// <summary>Gets or sets the type.</summary>
        /// <value>The type.</value>
        public IntegrationExceptionType Type { get; set; }

        /// <summary>Initializes a new instance of the <see cref="IntegrationException" /> class.</summary>
        public IntegrationException()
        { }

        /// <summary>Initializes a new instance of the <see cref="IntegrationException" /> class.</summary>
        /// <param name="type">The type.</param>
        /// <param name="message">The message.</param>
        public IntegrationException(IntegrationExceptionType type, string message) : base(message)
        {
            Type = type;
        }

        /// <summary>Initializes a new instance of the <see cref="IntegrationException" /> class.</summary>
        /// <param name="type">The type.</param>
        /// <param name="message">The message.</param>
        /// <param name="innerException">The inner exception.</param>
        public IntegrationException(IntegrationExceptionType type, string message, Exception innerException) : base(message, innerException)
        {
            Type = type;
        }
    }
}
