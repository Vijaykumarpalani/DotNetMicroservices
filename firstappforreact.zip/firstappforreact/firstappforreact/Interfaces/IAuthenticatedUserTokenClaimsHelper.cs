﻿using SampleCustomerAPI.Types.UserAudit;
using System.Security.Claims;

namespace SampleCustomerAPI.Interfaces
{
    /// <summary>
    /// Interface IAuthenticatedUserTokenClaimsHelper
    /// </summary>
    public interface IAuthenticatedUserTokenClaimsHelper
    {
        /// <summary>
        /// Get Authenticated User Details
        /// </summary>
        /// <param name="claimsPrincipal"></param>
        /// <returns></returns>
        public AuthenticatedUserDetails GetAuthenticatedUserDetails(ClaimsPrincipal claimsPrincipal);
    }
}
