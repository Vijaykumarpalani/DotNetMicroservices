﻿using SampleCustomerAPI.Model;

namespace SampleCustomerAPI.Interfaces.DAL
{
    /// <summary>
    /// 
    /// </summary>
    public interface IRepository
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="cutomerName"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        Task<Customer?> GetByCustomerId(string cutomerName, CancellationToken cancellationToken);

    }
}
